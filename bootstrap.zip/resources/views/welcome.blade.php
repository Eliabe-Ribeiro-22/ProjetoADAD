<!DOCTYPE html>
<html>
<head>
    <title>Projeto ADAD</title>
</head>
<body>
    <h1>Bem-vindo ao Projeto ADAD!</h1>
    <h2>Página Igreja AD CBS</h2>
    <h2>Página ADAD</h2>
</body>
</html>