{{-- Index Igreja --}}
@extends("layouts.template_church")

@section("titulo", "Inicio")

@section("corpo")
OK <!-- <x-igreja.main.main /> -->
@endsection