<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class AdadController extends Controller
{

    public function index(){
        return view('welcome');
    }

    public function arearestrita(){
        // exibir os alunos
    }

    public function store(){
        // salvar
    }
}
