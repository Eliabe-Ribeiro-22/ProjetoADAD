<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Aprendendo Laravel</title>
</head>
<body>
    <form action="" method="get">
        <input type="name" name="NOME">
        <input type="submit" name="ENVIAR">
    </form>

</body>
</html><?php /**PATH E:\Users\Acer\Desktop\hub\Deploy_teste\resources\views/welcome.blade.php ENDPATH**/ ?>