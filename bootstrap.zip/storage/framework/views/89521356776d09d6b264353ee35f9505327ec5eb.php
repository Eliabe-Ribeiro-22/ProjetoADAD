<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Aprendendo Laravel</title>
</head>
<body>
    <form action="<?php //rota para salvar?>" method="post">
        <input type="name" name="NOME">
        <input type="submit" name="cadastrar">
    </form>

</body>
</html><?php /**PATH E:\Users\Acer\Desktop\hub\ProjetoADAD_v4_teste_2\LaravelEliabe\laravelEliabe\resources\views/welcome.blade.php ENDPATH**/ ?>